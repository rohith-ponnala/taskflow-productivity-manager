import API from "./api";

export const getActivities = async () => {
  const res = await API.get("/activity");
  return res.data;
};