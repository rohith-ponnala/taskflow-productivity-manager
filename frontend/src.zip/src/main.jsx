import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App";

import "./styles/home.css";
import "./styles/auth.css";
import "./styles/dashboard.css";
import "./styles/darkmode.css";
import ThemeProvider from "./context/ThemeContext";

ReactDOM.createRoot(
  document.getElementById("root")
).render(
  <React.StrictMode>

    <ThemeProvider>

      <App />

    </ThemeProvider>

  </React.StrictMode>
);