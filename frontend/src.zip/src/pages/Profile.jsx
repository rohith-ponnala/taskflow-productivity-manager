import "../styles/profile.css";

function Profile() {

  const name =
    localStorage.getItem("userName") || "User";

  const email =
    localStorage.getItem("userEmail") || "No Email";

  return (

    <div className="profile-page">

      <div className="profile-card">

        <div className="profile-avatar-large">
          {name.charAt(0).toUpperCase()}
        </div>

        <h1>{name}</h1>

        <p>{email}</p>

      </div>

      <div className="profile-stats">

        <div className="profile-stat-card">
          <h2>🚀</h2>
          <p>Productive User</p>
        </div>

        <div className="profile-stat-card">
          <h2>🔥</h2>
          <p>Task Manager</p>
        </div>

        <div className="profile-stat-card">
          <h2>⭐</h2>
          <p>TodoMaster Pro</p>
        </div>

      </div>

    </div>

  );

}

export default Profile;