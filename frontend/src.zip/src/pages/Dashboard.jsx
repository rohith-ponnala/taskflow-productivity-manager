import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import API from "../services/api";
import ProfileDropdown from "../components/ProfileDropdown";
import CalendarView from "../components/CalendarView";

function Dashboard() {
  const navigate = useNavigate();

  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState("");
  const [editingId, setEditingId] =
  useState(null);

const [editTitle, setEditTitle] =
  useState("");

const [editPriority,
  setEditPriority] =
  useState("Medium");

const [editDueDate,
  setEditDueDate] =
  useState("");

  const [search, setSearch] = useState("");
  
  const userName =
  localStorage.getItem("userName") || "User";

  const [filter, setFilter] =
    useState("all");
    const [priority, setPriority] =
  useState("Medium");

const [dueDate, setDueDate] =
  useState("");

  const fetchTodos = async () => {
    try {
      const res = await API.get("/todos");
      setTodos(res.data);
    } catch (error) {
      toast.error("Failed to load todos");
    }
  };
  useEffect(() => {

  const token =
    localStorage.getItem("token");

  if (!token) {
    navigate("/login");
    return;
  }

  
  if (
  Notification.permission !==
  "granted"
) {
  Notification.requestPermission();
}
fetchTodos();
}, []);
useEffect(() => {

  const overdue = todos.filter(
    (todo) =>
      !todo.completed &&
      todo.dueDate &&
      new Date(todo.dueDate) <
      new Date()
  );

  if (
    overdue.length > 0 &&
    Notification.permission ===
      "granted"
  ) {

    new Notification(
      "⚠️ Todo Reminder",
      {
        body:
          `You have ${overdue.length} overdue task(s)`
      }
    );

  }

}, [todos]);

  const addTodo = async () => {
    if (!title.trim()) return;

    try {
      await API.post("/todos", {
  title,
  priority,
  dueDate,
});

      toast.success("Todo Added");

      setTitle("");
      setPriority("Medium");
setDueDate("");

      fetchTodos();

    } catch {
      toast.error("Failed");
    }
  };
  const updateTodo = async (id) => {

  try {

    await API.put(
      `/todos/${id}`,
      {
        title: editTitle,
        priority: editPriority,
        dueDate: editDueDate,
      }
    );

    toast.success(
      "Todo Updated"
    );

    setEditingId(null);

    fetchTodos();

  } catch {

    toast.error(
      "Update Failed"
    );

  }

};

  const toggleTodo = async (
    id,
    completed
  ) => {
    try {
      await API.put(`/todos/${id}`, {
        completed: !completed,
      });

      toast.success("Todo Updated");

      fetchTodos();
    } catch {
      toast.error("Update Failed");
    }
  };

  const deleteTodo = async (id) => {

  const confirmDelete =
    window.confirm(
      "Are you sure you want to delete this task?"
    );

  if (!confirmDelete) return;

  try {

    await API.delete(
      `/todos/${id}`
    );

    toast.success(
      "Todo Deleted"
    );

    fetchTodos();

  } catch {

    toast.error(
      "Delete Failed"
    );

  }
};

  const logout = () => {

  localStorage.removeItem("token");

  localStorage.removeItem("userName");

  toast.success("Logged Out");

  navigate("/login", {
    replace: true,
  });
};

  const filteredTodos =
    todos.filter((todo) => {

      const matchSearch =
        todo.title
          .toLowerCase()
          .includes(
            search.toLowerCase()
          );

      const matchFilter =
        filter === "all"
          ? true
          : filter === "completed"
          ? todo.completed
          : !todo.completed;

      return (
        matchSearch &&
        matchFilter
      );
    });

  const completed =
    todos.filter(
      (t) => t.completed
    ).length;

  const pending =
    todos.length - completed;

  const progress =
    todos.length === 0
      ? 0
      : Math.round(
          (completed /
            todos.length) *
            100
        );
const overdueTasks = todos.filter(
  (todo) =>
    !todo.completed &&
    todo.dueDate &&
    new Date(todo.dueDate) < new Date()
);
  return (
    <div className="dashboard">

      <div className="dashboard-navbar">

  <div className="dashboard-logo">
    ✓ TodoMaster Pro
  </div>

  <div className="nav-right">

    <div className="notification-icon">
      🔔
    </div>

    <ProfileDropdown />

  </div>

</div>

<p className="dashboard-subtitle">
  Organize your work and stay productive.
</p>

<div className="welcome-banner">

  <div className="welcome-header">

  <div>

    <h2>
      👋 Welcome Back, {userName}
    </h2>

    <p>
      Track tasks, monitor progress and
      complete your goals efficiently.
    </p>

  </div>

</div>

</div>
{overdueTasks.length > 0 && (

  <div className="overdue-alert">

    ⚠️ You have
    {" "}
    {overdueTasks.length}
    {" "}
    overdue task(s)

  </div>

)}

      <div className="stats">

  <div className="card">
    <span className="stat-icon">📋</span>
    <h3>Total</h3>
    <p>{todos.length}</p>
  </div>

  <div className="card">
    <span className="stat-icon">✅</span>
    <h3>Completed</h3>
    <p>{completed}</p>
  </div>

  <div className="card">
    <span className="stat-icon">⏳</span>
    <h3>Pending</h3>
    <p>{pending}</p>
  </div>

  <div className="card">
    <span className="stat-icon">📈</span>
    <h3>Progress</h3>
    <p>{progress}%</p>
  </div>

</div>

      <div className="ai-insights">

  <h2>🤖 AI Smart Insights</h2>

  <div className="insight-grid">

    <div className="insight-card">
      🔥 High Priority:
      {" "}
      {
        todos.filter(
          t => t.priority === "High"
        ).length
      }
    </div>

    <div className="insight-card">
      ⏰ Due Today:
      {" "}
      {
        todos.filter(
          t =>
            t.dueDate &&
            new Date(t.dueDate)
              .toDateString() ===
            new Date()
              .toDateString()
        ).length
      }
    </div>

    <div className="insight-card">
      🚀 Productivity:
      {" "}
      {progress}%
    </div>

  </div>

</div>

      <div className="controls">

        <input
          placeholder="Search Todo..."
          value={search}
          onChange={(e) =>
            setSearch(
              e.target.value
            )
          }
        />

        <select
          value={filter}
          onChange={(e) =>
            setFilter(
              e.target.value
            )
          }
        >
          <option value="all">
            All
          </option>

          <option value="completed">
            Completed
          </option>

          <option value="pending">
            Pending
          </option>

        </select>

      </div>

      <div className="add-box">

<input
  value={title}
  onChange={(e)=>
    setTitle(e.target.value)
  }
  placeholder="Enter Todo"
/>

<select
  value={priority}
  onChange={(e)=>
    setPriority(e.target.value)
  }
>

  <option>
    High
  </option>

  <option>
    Medium
  </option>

  <option>
    Low
  </option>

</select>

<input
  type="date"
  value={dueDate}
  onChange={(e)=>
    setDueDate(e.target.value)
  }
/>

<button onClick={addTodo}>
  Add Todo
</button>

</div>
<CalendarView
  todos={todos}
/>
      
       <div className="todo-list">

  {filteredTodos.length === 0 ? (

    <div className="empty-state">

      <h3>No Tasks Yet 🚀</h3>

      <p>
        Create your first task and start
        tracking your productivity.
      </p>

    </div>

  ) : (

    filteredTodos.map(
      (todo) => (
        <div
          key={todo._id}
          className="todo-item"
        >
          <div>

  {editingId ===
todo._id ? (

  <div
    className="edit-box"
  >

    <input
      value={editTitle}
      onChange={(e) =>
        setEditTitle(
          e.target.value
        )
      }
    />

    <select
      value={editPriority}
      onChange={(e) =>
        setEditPriority(
          e.target.value
        )
      }
    >

      <option>
        Low
      </option>

      <option>
        Medium
      </option>

      <option>
        High
      </option>

    </select>

    <input
      type="date"
      value={editDueDate} 
      onChange={(e) =>
        setEditDueDate(
          e.target.value
        )
      }
    />

    <button
      onClick={() =>
        updateTodo(
          todo._id
        )
      }
    >
      Save
    </button>

  </div>

) : (

  <span>
    {todo.title}
  </span>

)}

  <p className="priority-badge">

    {todo.priority === "High" &&
      "🔴 High"}

    {todo.priority === "Medium" &&
      "🟡 Medium"}

    {todo.priority === "Low" &&
      "🟢 Low"}

  </p>

  <p className="due-date">

    📅 {

      todo.dueDate
      ? new Date(
          todo.dueDate
        ).toLocaleDateString()

      : "No Due Date"

    }

  </p>

</div>

          <div>
            <button
onClick={() => {

  if (
    editingId === todo._id
  ) {

    setEditingId(null);
    return;

  }

  setEditingId(todo._id);

  setEditTitle(
    todo.title
  );

  setEditPriority(
    todo.priority ||
    "Medium"
  );

  setEditDueDate(
    todo.dueDate
      ? todo.dueDate.split("T")[0]
      : ""
  );

}}
>

{editingId === todo._id
  ? "Cancel"
  : "Edit"}

</button>

            <button
              onClick={() =>
                toggleTodo(
                  todo._id,
                  todo.completed
                )
              }
            >
              {todo.completed
                ? "Undo"
                : "Complete"}
            </button>

            <button
              onClick={() =>
                deleteTodo(
                  todo._id
                )
              }
            >
              Delete
            </button>

          </div>
        </div>
      )
    )

  )}

</div>

    </div>
  );
}

export default Dashboard;