import { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

function CalendarView({ todos }) {

  const [selectedDate, setSelectedDate] =
    useState(new Date());

  const getTasksForDate = (date) => {

    return todos.filter((todo) => {

      if (!todo.dueDate) return false;

      return (
        new Date(todo.dueDate)
          .toDateString() ===
        date.toDateString()
      );

    });

  };

  const selectedTasks =
    getTasksForDate(selectedDate);

  return (

    <div className="calendar-layout">

      {/* LEFT */}

      <div className="calendar-panel">

        <h2>
          📅 Smart Calendar
        </h2>

        <Calendar
          onChange={setSelectedDate}
          value={selectedDate}
          tileContent={({ date }) => {

            const tasks =
              getTasksForDate(date);

            if (!tasks.length)
              return null;

            return (
  <span className="task-indicator">
    ●
  </span>
);

          }}
        />

      </div>

      {/* RIGHT */}

      <div className="task-panel">

        <h2>
          📌 Tasks For{" "}
          {selectedDate.toLocaleDateString()}
        </h2>

        {

          selectedTasks.length === 0 ? (

            <div className="empty-day">

              No tasks scheduled

            </div>

          ) : (

            selectedTasks.map(
              (task) => (

                <div
                  key={task._id}
                  className="day-task-card"
                >

                  <h4>
                    {
                      task.completed
                        ? "✅"
                        : "📌"
                    }

                    {" "}

                    {task.title}
                  </h4>

                  <span
                    className={`priority-tag ${
                      task.priority
                    }`}
                  >

                    {task.priority}

                  </span>

                </div>

              )
            )

          )

        }

      </div>

    </div>

  );

}

export default CalendarView;